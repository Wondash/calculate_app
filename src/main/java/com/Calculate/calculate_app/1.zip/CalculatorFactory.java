package com.Calculate.calculate_app.service;

import com.Calculate.calculate_app.dao.Methods;
import org.springframework.stereotype.Service;

@Service
public class CalculatorFactory {
    public Calculator getCalculator(Methods methods) throws Exception {
        return (Calculator) Class.forName(methods.getClassName()).newInstance();
    }
}