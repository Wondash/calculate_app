package com.Calculate.calculate_app.service;

import com.Calculate.calculate_app.dto.TaskResult;
import org.springframework.transaction.annotation.Transactional;

import java.io.Serializable;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Map;

public interface CalculationService extends Remote {
    TaskResult submitTask(int methodId, Map<String,Serializable> parameters, int userId);

    @Transactional
    TaskResult submitTask(int methodId, Map<String, Serializable> params, int userId) throws RemoteException;
}
