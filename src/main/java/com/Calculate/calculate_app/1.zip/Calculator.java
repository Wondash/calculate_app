package com.Calculate.calculate_app.service;

import java.util.Map;

public interface Calculator {
    Object calculate(Map<String, Object> parameters) throws CalculationException;
}
