package com.Calculate.calculate_app.Config;

import com.Calculate.calculate_app.service.CalculationService;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.remoting.rmi.RmiRegistryFactoryBean;
import org.springframework.remoting.rmi.RmiServiceExporter;
@Configuration
public class RmiServerConfig {
    @Bean
    public RmiServiceExporter rmiExporter(@Qualifier("calculationService") CalculationService service) {
        RmiServiceExporter exporter = new RmiServiceExporter();
        exporter.setServiceInterface(CalculationService.class);
        exporter.setService(service);
        exporter.setServiceName("CalculationService");
        exporter.setRegistryPort(1099);
        return exporter;
    }

    @Bean
    public RmiRegistryFactoryBean rmiRegistry() {
        RmiRegistryFactoryBean rmiRegistry = new RmiRegistryFactoryBean();
        rmiRegistry.setPort(1099);
        return rmiRegistry;
    }
}
