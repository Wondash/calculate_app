package com.Calculate.calculate_app.service;

import aj.org.objectweb.asm.TypeReference;
import com.Calculate.calculate_app.dao.*;
import com.Calculate.calculate_app.dto.TaskResult;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

@Service
public class CalculationServiceImpl extends UnicastRemoteObject implements CalculationService {
    @Autowired
    private TasksRepository taskRepo;
    @Autowired private MethodsRepository methodRepo;
    @Autowired private UsersRepository userRepo;
    @Autowired private CalculatorFactory calculatorFactory;
    @Qualifier("applicationTaskExecutor")
    @Autowired private Executor asyncExecutor;

    public CalculationServiceImpl() throws RemoteException {
        super(); // 默认导出到随机端口，或指定固定端口 super(1098)
    }

    @Transactional
    @Override
    public TaskResult submitTask(int methodId, Map<String, Serializable> parameters, int userId) throws RemoteException {
        try {
            Methods method = methodRepo.findById(methodId)
                    .orElseThrow(() -> new RemoteException("Method not found"));
            Users user = userRepo.findById(userId)
                    .orElseThrow(() -> new RemoteException("User not found"));

            Tasks task = new Tasks();
            task.setMethod_id(methodId);
            task.setUser_id(userId);
            task.setParameters(new ObjectMapper().writeValueAsString(parameters));
            task.setStatus(Tasks.Status.进行中);
            task.setSubmitted_at(LocalDateTime.now());
            taskRepo.save(task);

            CompletableFuture.runAsync(() -> processTask(task), asyncExecutor);
            return new TaskResult(task.getId(), task.getStatus(), null);
        } catch (Exception e) {
            throw new RemoteException("Submit task failed: " + e.getMessage());
        }
    }

    @Override
    public TaskResult getTaskStatus(int taskId) throws RemoteException {
        Tasks task = taskRepo.findById(taskId)
                .orElseThrow(() -> new RemoteException("Task not found"));
        return new TaskResult(task.getId(), task.getStatus(), task.getResult());
    }

    @Async
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void processTask(Tasks task) {
        try {
            task.setStatus(Tasks.Status.进行中);
            taskRepo.save(task);

            Calculator calculator = calculatorFactory.getCalculator(MethodsRepository.findById(task.getMethod_id());
            Map<String, Serializable> params = new ObjectMapper().readValue(task.getParameters(),
                    new TypeReference<Map<String, Serializable>>() {});
            Object result = calculator.calculate(parameters);

            task.setResult(result.toString());
            task.setStatus(Tasks.Status.已完成);
        } catch (Exception e) {
            task.setResult("Error: " + e.getMessage());
            task.setStatus(Tasks.Status.失败);
        } finally {
            task.setCompleted_at(LocalDateTime.now());
            taskRepo.save(task);
        }
    }
}