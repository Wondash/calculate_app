package com.Calculate.calculate_app.Config;

import com.Calculate.calculate_app.service.CalculationService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

@Configuration
public class RmiClientConfig {
    @Bean
    public CalculationService calculationService() throws Exception {
        Registry registry = LocateRegistry.getRegistry("localhost", 1099);
        return (CalculationService) registry.lookup("CalculationService");
    }
}